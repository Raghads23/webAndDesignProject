
function openMessagePopup() {
    var messagePopup = document.getElementById('message-popup');
    messagePopup.classList.add('open');
}

function closeMessagePopup() {
    var messagePopup = document.getElementById('message-popup');
    messagePopup.classList.remove('open');
}

